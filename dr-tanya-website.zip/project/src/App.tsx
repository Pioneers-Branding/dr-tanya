import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ExcellenceStory from './components/ExcellenceStory';
import Services from './components/Services';
import Gallery from './components/Gallery';
import SuccessStories from './components/SuccessStories';
import Locations from './components/Locations';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <section id="home">
          <Hero />
        </section>
        <section id="about">
          <ExcellenceStory />
        </section>
        <section id="specializations">
          <Services />
        </section>
        <section id="gallery">
          <Gallery />
        </section>
        <section id="success-stories">
          <SuccessStories />
        </section>
        <section id="locations">
          <Locations />
        </section>
        <section id="contact">
          <Contact />
        </section>
      </main>
      <Footer />
    </div>
  );
}

export default App;