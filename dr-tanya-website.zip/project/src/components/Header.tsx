import React, { useState } from 'react';
import { Menu, X, Phone, Heart } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Specializations', href: '#specializations' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Success Stories', href: '#success-stories' },
    { name: 'Locations', href: '#locations' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#FFE1E0]/30 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#EB5490] to-[#2F3A8F] rounded-full flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#2F3A8F] font-serif">Dr. Tanya Buckshee Rohatgi</h1>
              <p className="text-sm text-[#EB5490] font-medium">Elite IVF Specialist</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-slate-700 hover:text-[#EB5490] font-medium transition-colors duration-300 relative group"
              >
                {item.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#EB5490] transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center space-x-4">
            <a href="tel:+918860444888" className="flex items-center space-x-2 text-[#2F3A8F] hover:text-[#EB5490] transition-colors">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">+91-8860 444 888</span>
            </a>
            <button className="bg-[#EB5490] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#2F3A8F] transition-all duration-300 hover:shadow-lg transform hover:scale-105">
              Book Consultation
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden w-10 h-10 flex items-center justify-center text-slate-700 hover:text-[#EB5490] transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-white border-b border-[#FFE1E0]/30 shadow-lg">
            <nav className="px-4 py-6 space-y-4">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-slate-700 hover:text-[#EB5490] font-medium py-2 transition-colors duration-300"
                >
                  {item.name}
                </a>
              ))}
              <div className="pt-4 border-t border-[#FFE1E0]/30">
                <a href="tel:+918860444888" className="flex items-center space-x-2 text-[#2F3A8F] mb-4">
                  <Phone className="w-4 h-4" />
                  <span className="font-semibold">+91-8860 444 888</span>
                </a>
                <button className="w-full bg-[#EB5490] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#2F3A8F] transition-all duration-300">
                  Book Consultation
                </button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;