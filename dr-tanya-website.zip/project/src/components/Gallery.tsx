import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Award, Building, Users, Microscope } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const galleryItems = [
    {
      id: 1,
      image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Modern Clinic Exterior',
      category: 'facilities',
      description: 'State-of-the-art fertility clinic with modern architecture'
    },
    {
      id: 2,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Advanced IVF Laboratory',
      category: 'facilities',
      description: 'Cutting-edge laboratory equipment for IVF procedures'
    },
    {
      id: 3,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Consultation Room',
      category: 'facilities',
      description: 'Comfortable and private consultation spaces'
    },
    {
      id: 4,
      image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Medical Conference',
      category: 'achievements',
      description: 'Dr. Rohatgi presenting at international fertility conference'
    },
    {
      id: 5,
      image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Patient Care Area',
      category: 'facilities',
      description: 'Comfortable recovery and waiting areas for patients'
    },
    {
      id: 6,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Research Laboratory',
      category: 'facilities',
      description: 'Advanced research facilities for fertility treatments'
    },
    {
      id: 7,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Award Ceremony',
      category: 'achievements',
      description: 'Recognition for excellence in reproductive medicine'
    },
    {
      id: 8,
      image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Team Meeting',
      category: 'team',
      description: 'Medical team discussing patient care protocols'
    },
    {
      id: 9,
      image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800',
      title: 'Happy Family',
      category: 'success',
      description: 'Celebrating successful fertility treatment outcomes'
    }
  ];

  const categories = [
    { id: 'all', name: 'All', icon: Building },
    { id: 'facilities', name: 'Facilities', icon: Building },
    { id: 'achievements', name: 'Achievements', icon: Award },
    { id: 'team', name: 'Our Team', icon: Users },
    { id: 'success', name: 'Success Stories', icon: Microscope }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedCategory);

  const openModal = (index: number) => {
    setSelectedImage(index);
  };

  const closeModal = () => {
    setSelectedImage(null);
  };

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % filteredItems.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-[#FFE1E0]/20" id="gallery">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Our
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Gallery
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            Take a glimpse into our world-class facilities, achievements, and the 
            moments that make our fertility journey special
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-[#EB5490] text-white shadow-lg'
                  : 'bg-white text-slate-700 hover:bg-[#FFE1E0] border border-slate-200'
              }`}
            >
              <category.icon className="w-5 h-5" />
              {category.name}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="group cursor-pointer"
              onClick={() => openModal(index)}
            >
              <div className="relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <h3 className="text-xl font-bold font-serif mb-2">{item.title}</h3>
                    <p className="text-sm opacity-90">{item.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {selectedImage !== null && (
          <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
            <div className="relative max-w-4xl w-full">
              {/* Close Button */}
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 z-10 w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors duration-300"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Navigation Buttons */}
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors duration-300"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors duration-300"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

              {/* Image */}
              <img
                src={filteredItems[selectedImage].image}
                alt={filteredItems[selectedImage].title}
                className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
              />

              {/* Image Info */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 text-white rounded-b-lg">
                <h3 className="text-2xl font-bold font-serif mb-2">
                  {filteredItems[selectedImage].title}
                </h3>
                <p className="text-lg opacity-90">
                  {filteredItems[selectedImage].description}
                </p>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-sm opacity-75">
                    {selectedImage + 1} of {filteredItems.length}
                  </span>
                  <span className="bg-[#EB5490] px-3 py-1 rounded-full text-sm font-semibold capitalize">
                    {filteredItems[selectedImage].category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-[#EB5490] to-[#2F3A8F] rounded-3xl p-8 md:p-12 text-white">
            <h3 className="text-3xl font-bold font-serif mb-4">
              Experience Excellence Firsthand
            </h3>
            <p className="text-xl mb-8 opacity-90 leading-relaxed">
              Schedule a visit to our state-of-the-art facilities and meet our expert team
            </p>
            <button className="bg-white text-[#EB5490] px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#FFE1E0] hover:shadow-lg transform hover:scale-105 transition-all duration-300">
              Schedule Facility Tour
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;