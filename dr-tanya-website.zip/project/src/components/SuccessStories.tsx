import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Star, Heart } from 'lucide-react';

const SuccessStories = () => {
  const [currentStory, setCurrentStory] = useState(0);

  const stories = [
    {
      name: "Priya & Rajesh",
      age: "32 & 35",
      treatment: "IVF with ICSI",
      story: "After 5 years of trying, we had almost given up hope. Dr. Rohatgi's personalized approach and advanced IVF techniques made our dream come true. Our little angel is now 2 years old!",
      outcome: "Successful pregnancy after 2 IVF cycles",
      location: "Delhi"
    },
    {
      name: "Meera & Arjun",
      age: "28 & 30",
      treatment: "Onco-Fertility Preservation",
      story: "When I was diagnosed with cancer, Dr. Rohatgi helped preserve my fertility before treatment. Today, we're blessed with twins through her expertise in onco-fertility.",
      outcome: "Successful twin pregnancy post-cancer treatment",
      location: "Gurgaon"
    },
    {
      name: "Kavita & Suresh",
      age: "35 & 38",
      treatment: "Male Factor Infertility",
      story: "Male factor infertility was our challenge. Dr. Rohatgi's comprehensive approach addressed both medical and emotional aspects. We now have a beautiful daughter.",
      outcome: "Successful pregnancy with advanced sperm treatment",
      location: "Noida"
    },
    {
      name: "Anjali & Vikram",
      age: "30 & 33",
      treatment: "PCOS Management",
      story: "PCOS made conception difficult. Dr. Rohatgi's holistic treatment plan not only helped us conceive but also improved my overall health significantly.",
      outcome: "Natural conception after PCOS treatment",
      location: "Faridabad"
    },
    {
      name: "Ritu & Amit",
      age: "34 & 36",
      treatment: "Recurrent Miscarriage",
      story: "After 3 miscarriages, we were heartbroken. Dr. Rohatgi's detailed investigation and treatment protocol helped us carry our pregnancy to full term.",
      outcome: "Successful full-term pregnancy",
      location: "Delhi"
    }
  ];

  const nextStory = () => {
    setCurrentStory((prev) => (prev + 1) % stories.length);
  };

  const prevStory = () => {
    setCurrentStory((prev) => (prev - 1 + stories.length) % stories.length);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-[#FFE1E0]/20" id="success-stories">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Success
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Stories
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            Real families, real journeys, real miracles. Discover how personalized 
            fertility care has transformed lives and created thousands of happy families
          </p>
        </div>

        {/* Story Carousel */}
        <div className="relative max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-[#FFE1E0]/30 min-h-[400px] flex flex-col justify-between">
            {/* Quote Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[#EB5490] to-[#2F3A8F] rounded-full flex items-center justify-center">
                <Quote className="w-8 h-8 text-white" />
              </div>
            </div>

            {/* Story Content */}
            <div className="text-center flex-grow">
              <blockquote className="text-xl md:text-2xl text-slate-700 font-light leading-relaxed mb-8 font-serif">
                "{stories[currentStory].story}"
              </blockquote>

              <div className="space-y-4">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="text-center">
                    <h4 className="text-xl font-bold text-[#2F3A8F] font-serif">
                      {stories[currentStory].name}
                    </h4>
                    <p className="text-slate-600">
                      Ages: {stories[currentStory].age} • {stories[currentStory].location}
                    </p>
                  </div>
                </div>

                <div className="bg-[#FFE1E0]/50 rounded-xl p-4 max-w-md mx-auto">
                  <div className="text-sm text-slate-600 mb-2">Treatment:</div>
                  <div className="font-semibold text-[#EB5490]">{stories[currentStory].treatment}</div>
                </div>

                <div className="bg-gradient-to-r from-[#EB5490]/10 to-[#2F3A8F]/10 rounded-xl p-4 max-w-lg mx-auto">
                  <div className="text-sm text-slate-600 mb-2">Outcome:</div>
                  <div className="font-semibold text-[#2F3A8F]">{stories[currentStory].outcome}</div>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={prevStory}
                className="w-12 h-12 bg-[#FFE1E0] hover:bg-[#EB5490] hover:text-white rounded-full flex items-center justify-center transition-all duration-300 group"
              >
                <ChevronLeft className="w-6 h-6 text-[#2F3A8F] group-hover:text-white" />
              </button>

              {/* Story Indicators */}
              <div className="flex space-x-2">
                {stories.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentStory(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentStory
                        ? 'bg-[#EB5490] w-8'
                        : 'bg-slate-300 hover:bg-[#EB5490]/50'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={nextStory}
                className="w-12 h-12 bg-[#FFE1E0] hover:bg-[#EB5490] hover:text-white rounded-full flex items-center justify-center transition-all duration-300 group"
              >
                <ChevronRight className="w-6 h-6 text-[#2F3A8F] group-hover:text-white" />
              </button>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-[#EB5490] to-[#2F3A8F] rounded-3xl p-8 md:p-12 text-white">
            <div className="max-w-3xl mx-auto">
              <Heart className="w-16 h-16 mx-auto mb-6 opacity-80" />
              <h3 className="text-3xl font-bold font-serif mb-4">
                Your Success Story Awaits
              </h3>
              <p className="text-xl mb-8 opacity-90 leading-relaxed">
                Join thousands of families who have realized their dreams of parenthood. 
                Every journey is unique, and yours could be the next success story.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-[#EB5490] px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#FFE1E0] hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                  Share Your Story
                </button>
                <button className="border-2 border-white text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white hover:text-[#EB5490] transition-all duration-300">
                  Start Your Journey
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;