import React from 'react';
import { Award, Users, Clock, Globe, Star, Heart } from 'lucide-react';

const Hero = () => {
  const stats = [
    { icon: Users, value: '5000+', label: 'Happy Families' },
    { icon: Award, value: '21+', label: 'Years Experience' },
    { icon: Clock, value: '85%', label: 'Success Rate' },
    { icon: Globe, value: '15+', label: 'Countries Trained' }
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-[#FFE1E0]/20 via-white to-slate-50 pt-20">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-[#EB5490] rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-[#2F3A8F] rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center space-x-2 bg-[#FFE1E0]/50 px-4 py-2 rounded-full mb-6">
              <Star className="w-4 h-4 text-[#EB5490]" />
              <span className="text-sm font-semibold text-[#2F3A8F]">FRCOG Certified • International Expert</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-slate-900 font-serif mb-6 leading-tight">
              Dr. Tanya
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
                Buckshee Rohatgi
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-slate-600 mb-4 font-light">
              Elite IVF Specialist & Reproductive Endocrinologist
            </p>

            <p className="text-lg text-slate-600 mb-8 max-w-2xl">
              Transform your fertility dreams with 21+ years of global excellence. 
              Pioneer in Onco-fertility, FRCOG certified, with international training 
              across 15+ countries.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <button className="bg-[#EB5490] text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#2F3A8F] hover:shadow-xl transform hover:scale-105 transition-all duration-300">
                Book Consultation
              </button>
              <button className="border-2 border-[#2F3A8F] text-[#2F3A8F] px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#2F3A8F] hover:text-white transition-all duration-300">
                View Success Stories
              </button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-white/80 rounded-2xl shadow-lg border border-[#FFE1E0]/30">
                  <stat.icon className="w-6 h-6 text-[#EB5490] mx-auto mb-2" />
                  <div className="text-2xl font-bold text-[#2F3A8F] font-serif">{stat.value}</div>
                  <div className="text-sm text-slate-600 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image/Visual */}
          <div className="relative">
            <div className="relative bg-gradient-to-br from-[#FFE1E0] to-[#EB5490]/20 rounded-3xl p-8 shadow-2xl">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-[#FFE1E0] to-[#EB5490] rounded-full mx-auto mb-6 flex items-center justify-center">
                    <Heart className="w-16 h-16 text-[#2F3A8F]" />
                  </div>
                  <h3 className="text-2xl font-bold text-[#2F3A8F] font-serif mb-4">
                    Your Fertility Journey Starts Here
                  </h3>
                  <p className="text-slate-600 mb-6">
                    Personalized care with cutting-edge technology and compassionate support
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-[#FFE1E0]/30 rounded-xl">
                      <span className="font-medium text-slate-700">Initial Consultation</span>
                      <span className="text-[#EB5490] font-bold">Free</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-[#FFE1E0]/30 rounded-xl">
                      <span className="font-medium text-slate-700">Success Rate</span>
                      <span className="text-[#EB5490] font-bold">85%+</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-[#FFE1E0]/30 rounded-xl">
                      <span className="font-medium text-slate-700">Experience</span>
                      <span className="text-[#EB5490] font-bold">21+ Years</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-[#EB5490] rounded-full flex items-center justify-center shadow-lg">
              <Award className="w-10 h-10 text-white" />
            </div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-[#2F3A8F] rounded-full flex items-center justify-center shadow-lg">
              <Globe className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;