import React from 'react';
import { Award, Globe, Users, BookOpen, Heart, Shield } from 'lucide-react';

const ExcellenceStory = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-[#FFE1E0]/30 to-white" id="about">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Excellence
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Story
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            A journey of dedication, innovation, and compassionate care spanning over two decades
          </p>
        </div>

        {/* Doctor Profile Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Doctor Image */}
          <div className="relative">
            <div className="bg-gradient-to-br from-[#FFE1E0] to-[#EB5490]/20 rounded-3xl p-8 shadow-2xl">
              <div className="bg-white rounded-2xl p-8 shadow-lg text-center">
                <div className="w-32 h-32 bg-gradient-to-br from-[#FFE1E0] to-[#EB5490] rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Heart className="w-16 h-16 text-[#2F3A8F]" />
                </div>
                <h3 className="text-2xl font-bold text-[#2F3A8F] font-serif mb-2">
                  Dr. Tanya Buckshee Rohatgi
                </h3>
                <p className="text-[#EB5490] font-semibold mb-4">FRCOG, Elite IVF Specialist</p>
                <div className="space-y-2 text-sm text-slate-600">
                  <div className="flex items-center justify-center gap-2">
                    <Award className="w-4 h-4 text-[#EB5490]" />
                    <span>Fellow of Royal College (FRCOG)</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Globe className="w-4 h-4 text-[#EB5490]" />
                    <span>International Training - 15+ Countries</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Users className="w-4 h-4 text-[#EB5490]" />
                    <span>5000+ Happy Families</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Doctor Details */}
          <div>
            <h3 className="text-3xl font-bold text-slate-900 font-serif mb-6">
              Pioneering Excellence in Reproductive Medicine
            </h3>
            <div className="space-y-6 text-slate-600 leading-relaxed">
              <p className="text-lg">
                With over 21 years of dedicated service in reproductive medicine, 
                Dr. Tanya Buckshee Rohatgi stands as a beacon of hope for thousands 
                of families worldwide.
              </p>
              <p>
                As a Fellow of the Royal College of Obstetricians and Gynaecologists (FRCOG), 
                she brings unparalleled expertise in advanced fertility treatments, 
                combining cutting-edge technology with compassionate patient care.
              </p>
              <p>
                Her pioneering work in Onco-fertility has made her the first specialist 
                in India to offer comprehensive fertility preservation services for 
                cancer patients, opening new doors of hope for those facing challenging diagnoses.
              </p>
            </div>

            {/* Key Highlights */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-[#FFE1E0]/50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-[#2F3A8F] font-serif">21+</div>
                <div className="text-sm text-slate-600 font-medium">Years Experience</div>
              </div>
              <div className="bg-[#FFE1E0]/50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-[#2F3A8F] font-serif">85%</div>
                <div className="text-sm text-slate-600 font-medium">Success Rate</div>
              </div>
              <div className="bg-[#FFE1E0]/50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-[#2F3A8F] font-serif">5000+</div>
                <div className="text-sm text-slate-600 font-medium">Happy Families</div>
              </div>
              <div className="bg-[#FFE1E0]/50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-[#2F3A8F] font-serif">15+</div>
                <div className="text-sm text-slate-600 font-medium">Countries</div>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Quote */}
        <div className="bg-gradient-to-r from-[#EB5490] to-[#2F3A8F] rounded-3xl p-12 text-white text-center">
          <div className="max-w-4xl mx-auto">
            <blockquote className="text-2xl md:text-3xl font-light font-serif mb-6 leading-relaxed">
              "Every couple's journey to parenthood is unique. My mission is to provide 
              personalized, compassionate care while leveraging the latest advances in 
              reproductive medicine to turn dreams into reality."
            </blockquote>
            <div className="flex items-center justify-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <div className="text-left">
                <div className="font-bold text-xl">Dr. Tanya Buckshee Rohatgi</div>
                <div className="text-white/80">FRCOG, Elite IVF Specialist</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExcellenceStory;