import React from 'react';
import { MapPin, Phone, Clock, Navigation, Award, Users } from 'lucide-react';

const Locations = () => {
  const locations = [
    {
      id: 1,
      name: 'Max Multi Speciality Centre, Panchsheel Park',
      address: 'N-110, Panchsheel Park, New Delhi-110 017',
      phone: '+91-11-4609 7200',
      appointmentPhone: '+91-8860 444 888',
      timings: [
        'Mon: 9:00 am - 2:00 pm',
        'Tue & Fri: 3:00 pm - 5:00 pm', 
        'Wed: 9:00 am - 12:00 pm',
        'Thu: 9:00 am - 1:00 pm',
        'Sat: 9:00 am - 3:00 pm'
      ],
      isMain: true,
      image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['Main Consultation Centre', 'IVF Laboratory', 'Complete Fertility Services']
    },
    {
      id: 2,
      name: 'Max Super Speciality Hospital, Saket (West Block)',
      address: 'West Block, Saket, New Delhi',
      phone: '+91-8860 444 888',
      timings: [
        'Wed: 4:00 pm - 8:00 pm'
      ],
      isMain: false,
      image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['Super Speciality Care', 'Advanced Procedures', 'Surgical Facilities']
    },
    {
      id: 3,
      name: 'Max Hospital, Gurgaon',
      address: 'Gurgaon, Haryana',
      phone: '+91-8860 444 888',
      timings: [
        'Mon: 3:00 pm - 5:00 pm',
        'Fri: 12:00 pm - 2:00 pm',
        'Sat: 4:00 pm - 6:00 pm'
      ],
      isMain: false,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['Comprehensive Care', 'Modern Facilities', 'Expert Team']
    },
    {
      id: 4,
      name: 'Max MedCentre, Lajpat Nagar',
      address: 'Lajpat Nagar, New Delhi',
      phone: '+91-8860 444 888',
      timings: [
        'Thu & Sat: 2:00 pm - 4:00 pm'
      ],
      isMain: false,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['Convenient Location', 'Quality Care', 'Accessible Services']
    },
    {
      id: 5,
      name: 'Max Smart Super Speciality Hospital, Saket',
      address: 'Saket, New Delhi',
      phone: '+91-8860 444 888',
      timings: [
        'Tue: 9:00 am - 11:00 am',
        'Wed: 3:00 pm - 5:00 pm',
        'Fri: 12:00 pm - 3:00 pm'
      ],
      isMain: false,
      image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=800',
      features: ['Smart Healthcare', 'Advanced Technology', 'Premium Care']
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-[#FFE1E0]/20" id="locations">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Our
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Locations
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            Conveniently located across Delhi NCR with state-of-the-art facilities 
            and comprehensive fertility care services
          </p>
        </div>

        {/* Main Location Highlight */}
        <div className="mb-16">
          <div className="bg-gradient-to-r from-[#EB5490] to-[#2F3A8F] rounded-3xl p-8 text-white text-center">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center justify-center gap-4 mb-6">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <MapPin className="w-8 h-8 text-white" />
                </div>
                <div className="text-left">
                  <h3 className="text-2xl font-bold font-serif">Main Consultation Centre</h3>
                  <p className="text-white/90">Primary location with full facilities</p>
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold font-serif mb-2">21+</div>
                  <div className="text-white/80">Years Experience</div>
                </div>
                <div>
                  <div className="text-3xl font-bold font-serif mb-2">5000+</div>
                  <div className="text-white/80">Happy Families</div>
                </div>
                <div>
                  <div className="text-3xl font-bold font-serif mb-2">85%</div>
                  <div className="text-white/80">Success Rate</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Locations Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          {locations.map((location) => (
            <div
              key={location.id}
              className={`${
                location.isMain
                  ? 'bg-gradient-to-br from-[#FFE1E0] to-white border-[#EB5490]/20 shadow-lg'
                  : 'bg-white border-slate-200/50'
              } rounded-2xl p-8 shadow-lg border hover:shadow-xl 
              hover:scale-105 transition-all duration-500 group cursor-pointer`}
            >
              {/* Location Image */}
              <div className="aspect-video rounded-xl overflow-hidden mb-6">
                <img 
                  src={location.image} 
                  alt={location.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              {/* Main Badge */}
              {location.isMain && (
                <div className="inline-flex items-center gap-2 bg-[#EB5490] text-white px-4 py-2 rounded-full text-sm font-semibold mb-4">
                  <Award className="w-4 h-4" />
                  Main Centre
                </div>
              )}

              {/* Location Info */}
              <h3 className="text-xl font-bold text-slate-900 font-serif mb-3">
                {location.name}
              </h3>

              <div className="space-y-4 mb-6">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                  <p className="text-slate-600">{location.address}</p>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-slate-600">{location.phone}</p>
                    {location.appointmentPhone && location.appointmentPhone !== location.phone && (
                      <p className="text-slate-500 text-sm">Appointments: {location.appointmentPhone}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-700 mb-1">Consultation Hours:</p>
                    {location.timings.map((timing, index) => (
                      <p key={index} className="text-slate-600 text-sm">{timing}</p>
                    ))}
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-2 mb-6">
                <p className="font-semibold text-slate-700 text-sm">Available Services:</p>
                {location.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      location.isMain ? 'bg-[#EB5490]' : 'bg-slate-400'
                    }`}></div>
                    <span className="text-sm text-slate-600 font-medium">{feature}</span>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button className={`flex-1 py-3 px-4 rounded-xl font-semibold transition-all duration-300 ${
                  location.isMain
                    ? 'bg-[#EB5490] text-white hover:bg-[#2F3A8F]'
                    : 'bg-slate-600 text-white hover:bg-[#EB5490]'
                } hover:shadow-lg transform hover:scale-105`}>
                  Book Appointment
                </button>
                <button className="flex-1 border-2 border-[#2F3A8F] text-[#2F3A8F] py-3 px-4 rounded-xl font-semibold hover:bg-[#2F3A8F] hover:text-white transition-all duration-300 flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4" />
                  Get Directions
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-[#FFE1E0]/30 max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[#EB5490] to-[#2F3A8F] rounded-full flex items-center justify-center">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-2xl font-bold text-slate-900 font-serif">Ready to Schedule?</h3>
                <p className="text-slate-600">Call us for appointments at any location</p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="text-center p-4 bg-[#FFE1E0]/30 rounded-xl">
                <p className="font-semibold text-slate-700 mb-2">General Appointments</p>
                <p className="text-2xl font-bold text-[#EB5490]">+91-8860 444 888</p>
              </div>
              <div className="text-center p-4 bg-[#FFE1E0]/30 rounded-xl">
                <p className="font-semibold text-slate-700 mb-2">Panchsheel Park Direct</p>
                <p className="text-2xl font-bold text-[#EB5490]">+91-11-4609 7200</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-[#EB5490] text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#2F3A8F] hover:shadow-lg transform hover:scale-105 transition-all duration-300">
                Book Consultation Now
              </button>
              <button className="border-2 border-[#2F3A8F] text-[#2F3A8F] px-8 py-4 rounded-2xl font-bold text-lg hover:bg-[#2F3A8F] hover:text-white transition-all duration-300">
                Download Max MyHealth App
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Locations;