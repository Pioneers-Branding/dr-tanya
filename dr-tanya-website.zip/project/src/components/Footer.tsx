import React from 'react';
import { Heart, Phone, Mail, MapPin, Clock, Award, Users, Globe } from 'lucide-react';

const Footer = () => {
  const locations = [
    {
      name: 'Max Multi Speciality Centre, Panchsheel Park',
      address: 'N-110, Panchsheel Park, New Delhi-110 017',
      phone: '+91-11-4609 7200',
      timings: 'Mon: 9:00 am - 2:00 pm, Tue & Fri: 3:00 pm - 5:00 pm, Wed: 9:00 am - 12:00 pm'
    },
    {
      name: 'Max Super Speciality Hospital, Saket',
      address: 'West Block, Saket',
      timings: 'Wed: 4:00 pm - 8:00 pm'
    },
    {
      name: 'Max Hospital, Gurgaon',
      address: 'Gurgaon',
      timings: 'Mon: 3:00 pm - 5:00 pm, Fri: 12:00 pm - 2:00 pm, Sat: 4:00 pm - 6:00 pm'
    }
  ];

  const memberships = [
    'British Fertility Society, UK',
    'Royal College of Obstetricians and Gynaecologists (RCOG)',
    'European Society of Human Reproduction and Embryology (ESHRE)',
    'Indian Fertility Society (IFS)',
    'Association of Obstetricians and Gynaecologists of Delhi (AOGD)'
  ];

  return (
    <footer className="bg-gradient-to-br from-[#2F3A8F] to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="grid lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#EB5490] to-white rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-[#2F3A8F]" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-serif">Dr. Tanya Buckshee Rohatgi</h3>
                <p className="text-[#EB5490] font-medium">Elite IVF Specialist</p>
              </div>
            </div>
            <p className="text-slate-300 leading-relaxed mb-6">
              FRCOG certified fertility specialist with 21+ years of experience, 
              pioneering excellence in reproductive medicine and onco-fertility.
            </p>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-[#EB5490]" />
                <span>5000+ Families</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#EB5490]" />
                <span>85% Success</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold font-serif mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-slate-300 hover:text-[#EB5490] transition-colors">Home</a></li>
              <li><a href="#about" className="text-slate-300 hover:text-[#EB5490] transition-colors">About Dr. Rohatgi</a></li>
              <li><a href="#specializations" className="text-slate-300 hover:text-[#EB5490] transition-colors">Specializations</a></li>
              <li><a href="#gallery" className="text-slate-300 hover:text-[#EB5490] transition-colors">Gallery</a></li>
              <li><a href="#success-stories" className="text-slate-300 hover:text-[#EB5490] transition-colors">Success Stories</a></li>
              <li><a href="#locations" className="text-slate-300 hover:text-[#EB5490] transition-colors">Locations</a></li>
              <li><a href="#contact" className="text-slate-300 hover:text-[#EB5490] transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold font-serif mb-6">Specializations</h4>
            <ul className="space-y-3 text-slate-300">
              <li>Advanced IVF & ICSI</li>
              <li>Onco-Fertility (Cancer Patients)</li>
              <li>Male Factor Infertility</li>
              <li>Genetic Screening (PGD)</li>
              <li>Reproductive Endocrinology</li>
              <li>Ovarian Rejuvenation (PRP)</li>
              <li>Recurrent Implantation Failure</li>
              <li>Minimally Invasive Surgery</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold font-serif mb-6">Contact Information</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Appointments</p>
                  <p className="text-slate-300">+91-8860 444 888</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Email</p>
                  <p className="text-slate-300">info@maxhealthcare.in</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Main Location</p>
                  <p className="text-slate-300">Max Multi Speciality Centre</p>
                  <p className="text-slate-300">N-110, Panchsheel Park, New Delhi-110 017</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Globe className="w-5 h-5 text-[#EB5490] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-semibold">Website</p>
                  <p className="text-slate-300">www.maxhealthcare.in</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Professional Memberships */}
        <div className="border-t border-slate-700 mt-12 pt-8">
          <h4 className="text-lg font-bold font-serif mb-4">Professional Memberships</h4>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm text-slate-300">
            {memberships.map((membership, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-2 h-2 bg-[#EB5490] rounded-full flex-shrink-0"></div>
                <span>{membership}</span>
              </div>
            ))}
          </div>
        </div>

        {/* All Locations */}
        <div className="border-t border-slate-700 mt-8 pt-8">
          <h4 className="text-lg font-bold font-serif mb-4">All Consultation Locations</h4>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
            {locations.map((location, index) => (
              <div key={index} className="bg-slate-800/50 rounded-xl p-4">
                <h5 className="font-semibold text-[#EB5490] mb-2">{location.name}</h5>
                <p className="text-slate-300 mb-2">{location.address}</p>
                {location.phone && (
                  <p className="text-slate-300 mb-2">📞 {location.phone}</p>
                )}
                <p className="text-slate-400 text-xs">{location.timings}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm mb-4 md:mb-0">
            © 2024 Dr. Tanya Buckshee Rohatgi. All rights reserved. | Max Healthcare Network
          </p>
          <div className="flex items-center gap-6 text-sm text-slate-400">
            <span>FRCOG Certified</span>
            <span>•</span>
            <span>21+ Years Experience</span>
            <span>•</span>
            <span>5000+ Happy Families</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;