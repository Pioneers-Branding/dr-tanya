import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, Heart, Award } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
    preferredTime: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section className="py-16 bg-gradient-to-br from-[#FFE1E0]/20 to-slate-50" id="contact">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Get In
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Touch
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            Take the first step towards your fertility journey. Schedule your consultation 
            with Dr. Tanya Buckshee Rohatgi today.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Contact Information */}
          <div>
            <div className="bg-gradient-to-br from-[#EB5490] to-[#2F3A8F] rounded-3xl p-8 text-white mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold font-serif">Ready to Start?</h3>
                  <p className="text-white/90">Your fertility journey begins here</p>
                </div>
              </div>
              <p className="text-lg leading-relaxed mb-6">
                Schedule your personalized consultation with Dr. Tanya Buckshee Rohatgi, 
                FRCOG certified fertility specialist with 21+ years of experience.
              </p>
              <div className="flex items-center gap-3">
                <Award className="w-5 h-5 text-white/80" />
                <span className="text-white/90">85% Success Rate • 5000+ Happy Families</span>
              </div>
            </div>

            {/* Contact Details */}
            <div className="space-y-6">
              <div className="flex items-start gap-4 p-6 bg-white rounded-2xl shadow-lg border border-[#FFE1E0]/30">
                <div className="w-12 h-12 bg-[#FFE1E0] rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-[#EB5490]" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Phone</h4>
                  <p className="text-slate-600 mb-1">Appointments: +91-8860 444 888</p>
                  <p className="text-slate-600">Panchsheel Park: +91-11-4609 7200</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white rounded-2xl shadow-lg border border-[#FFE1E0]/30">
                <div className="w-12 h-12 bg-[#FFE1E0] rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-[#EB5490]" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Email & Website</h4>
                  <p className="text-slate-600 mb-1">info@maxhealthcare.in</p>
                  <p className="text-slate-600">www.maxhealthcare.in</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white rounded-2xl shadow-lg border border-[#FFE1E0]/30">
                <div className="w-12 h-12 bg-[#FFE1E0] rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-[#EB5490]" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Main Location</h4>
                  <p className="text-slate-600">Max Multi Speciality Centre</p>
                  <p className="text-slate-600">N-110, Panchsheel Park, New Delhi-110 017</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white rounded-2xl shadow-lg border border-[#FFE1E0]/30">
                <div className="w-12 h-12 bg-[#FFE1E0] rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-[#EB5490]" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Consultation Hours</h4>
                  <p className="text-slate-600 mb-1">Mon: 9:00 am - 2:00 pm</p>
                  <p className="text-slate-600 mb-1">Tue & Fri: 3:00 pm - 5:00 pm</p>
                  <p className="text-slate-600">Wed: 9:00 am - 12:00 pm</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-[#FFE1E0]/30">
            <h3 className="text-3xl font-bold text-slate-900 font-serif mb-6">
              Book Your Consultation
            </h3>
            <p className="text-slate-600 mb-8">
              Fill out the form below and we'll get back to you within 24 hours to schedule your appointment.
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#EB5490] focus:border-transparent transition-all duration-300"
                    placeholder="Enter your full name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#EB5490] focus:border-transparent transition-all duration-300"
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#EB5490] focus:border-transparent transition-all duration-300"
                  placeholder="your.email@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Preferred Consultation Time
                </label>
                <select
                  name="preferredTime"
                  value={formData.preferredTime}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#EB5490] focus:border-transparent transition-all duration-300"
                >
                  <option value="">Select preferred time</option>
                  <option value="morning">Morning (9:00 AM - 12:00 PM)</option>
                  <option value="afternoon">Afternoon (12:00 PM - 5:00 PM)</option>
                  <option value="evening">Evening (5:00 PM - 8:00 PM)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#EB5490] focus:border-transparent transition-all duration-300 resize-none"
                  placeholder="Tell us about your fertility concerns or questions..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-[#EB5490] text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-[#2F3A8F] hover:shadow-lg transform hover:scale-105 transition-all duration-300 flex items-center justify-center gap-3"
              >
                <Send className="w-5 h-5" />
                Schedule Consultation
              </button>
            </form>

            <div className="mt-6 p-4 bg-[#FFE1E0]/30 rounded-xl">
              <p className="text-sm text-slate-600 text-center">
                <strong>Free Initial Consultation</strong> • Confidential & Secure • 
                Response within 24 hours
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;