import React from 'react';
import { 
  Heart, 
  Microscope, 
  Shield, 
  Dna, 
  Activity, 
  Sparkles, 
  Target, 
  Scissors 
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Heart,
      title: 'Advanced IVF Excellence',
      description: 'State-of-the-art IVF and ICSI technologies with personalized protocols for optimal success rates',
      features: ['Latest Laboratory Technology', 'Personalized Treatment Plans', 'High Success Rates'],
      highlight: true,
      image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Microscope,
      title: 'Male Fertility Mastery',
      description: 'Comprehensive solutions for male factor infertility with advanced diagnostic techniques',
      features: ['Sperm Analysis', 'Hormonal Assessment', 'Surgical Interventions'],
      highlight: false,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Shield,
      title: 'Onco-Fertility Pioneer',
      description: 'Groundbreaking fertility preservation for cancer patients - first in India',
      features: ['Egg/Sperm Banking', 'Pre-treatment Planning', 'Post-cancer Care'],
      highlight: true,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Dna,
      title: 'Genetic Screening PGD',
      description: 'Preimplantation genetic diagnosis ensuring healthy embryo selection',
      features: ['Genetic Counseling', 'Embryo Testing', 'Family Planning'],
      highlight: false,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Activity,
      title: 'Hormonal Harmony',
      description: 'Expert reproductive endocrinology management for optimal fertility outcomes',
      features: ['Hormone Analysis', 'PCOS Treatment', 'Ovulation Disorders'],
      highlight: false,
      image: 'https://images.pexels.com/photos/3786126/pexels-photo-3786126.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Sparkles,
      title: 'Ovarian Rejuvenation',
      description: 'Revolutionary PRP therapy for ovarian function enhancement',
      features: ['PRP Treatment', 'Ovarian Health', 'Natural Enhancement'],
      highlight: true,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Target,
      title: 'Implantation Success',
      description: 'Specialized protocols for recurrent implantation failure treatment',
      features: ['Advanced Diagnostics', 'Immune Testing', 'Success Optimization'],
      highlight: false,
      image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Scissors,
      title: 'Minimally Invasive Surgery',
      description: 'Advanced laparoscopic techniques for reproductive health optimization',
      features: ['Laparoscopic Surgery', 'Quick Recovery', 'Precision Techniques'],
      highlight: false,
      image: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=600'
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-[#FFE1E0]/20 to-slate-50" id="specializations">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-slate-900 font-serif mb-6">
            Signature
            <span className="block text-transparent bg-clip-text 
                           bg-gradient-to-r from-[#EB5490] to-[#2F3A8F]">
              Specializations
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto font-light leading-relaxed">
            Comprehensive fertility solutions combining cutting-edge technology 
            with personalized care for your unique journey
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className={`${
                service.highlight
                  ? 'bg-gradient-to-br from-[#FFE1E0] to-white border-[#EB5490]/20'
                  : 'bg-white border-slate-200/50'
              } rounded-2xl p-6 shadow-lg border hover:shadow-xl 
              hover:scale-105 transition-all duration-500 group cursor-pointer 
              flex flex-col`}
            >
              {/* Service Image */}
              <div className="aspect-video rounded-xl overflow-hidden mb-6">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl ${
                service.highlight 
                  ? 'bg-gradient-to-br from-[#EB5490] to-[#2F3A8F]' 
                  : 'bg-gradient-to-br from-slate-100 to-slate-200'
              } flex items-center justify-center mb-4 group-hover:scale-110 
              transition-transform duration-300`}>
                <service.icon className={`w-6 h-6 ${
                  service.highlight ? 'text-white' : 'text-slate-700'
                }`} />
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-slate-900 font-serif mb-3">
                {service.title}
              </h3>
              <p className="text-slate-600 leading-relaxed mb-4 flex-grow">
                {service.description}
              </p>

              {/* Features */}
              <div className="space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      service.highlight ? 'bg-[#EB5490]' : 'bg-slate-400'
                    }`}></div>
                    <span className="text-sm text-slate-700 font-medium">
                      {feature}
                    </span>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <button className={`w-full py-3 rounded-xl font-semibold
                transition-all duration-300 ${
                service.highlight
                  ? 'bg-[#EB5490] text-white hover:bg-[#2F3A8F]'
                  : 'bg-slate-600 text-white hover:bg-[#EB5490]'
              } hover:shadow-lg transform hover:scale-105`}>
                Learn More
              </button>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex flex-col sm:flex-row items-center gap-6 
                          bg-white rounded-3xl p-8 shadow-xl border border-[#FFE1E0]/30">
            <div className="text-center sm:text-left">
              <h3 className="text-2xl font-bold text-slate-900 font-serif mb-2">
                Ready to Begin Your Journey?
              </h3>
              <p className="text-slate-600">
                Schedule your personalized consultation today
              </p>
            </div>
            <button className="bg-[#EB5490] text-white px-8 py-4 rounded-2xl font-bold 
                             hover:bg-[#2F3A8F]
                             hover:shadow-lg transform hover:scale-105 
                             transition-all duration-300 whitespace-nowrap">
              Book Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;